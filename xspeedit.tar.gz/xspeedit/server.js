var express = require('express');

var app = express();

app.listen(function(){
	console.log('Veuillez saisir les dimensions des articles a emballer:');
});

var stdin = process.openStdin();

stdin.addListener("data", function(d) {
        var liste=null;
        var chaine = new Array();
        
        liste = d.toString().trim();
		for (m=0; m<liste.length; m++)
			chaine[m]=Number(liste[m]);  


/*Fonction qui teste si l'embalage des articles dans l'ordre est optimal*/
			Remplissage = function (chaine1)
					{ var art=0;
	    			  var y=0;

						while (art < 10) {
								art = art + chaine1[y];	
								y++;} 

						if (art == 10) return (y-1);
						else return false;
					} 

/*Fonction qui recherche le(s) article(s) complémentaire*/
			complement = function (comp1, chaine1){
    			var v=1;
					while(comp1 > 0 && v <= chaine1.length)
					{
						if (chaine1[v] == comp1)
						{
							return (v);
						}	
						else{
     						v++;
     						}
 
							if (v == chaine1.length) {v=1; comp1--;}	
						
					}
					
				}


			main = function(){
					
					var j=0;
					var k=0;
					var retour=null;
					var resultat = new Array();
					var comp = 0;
					var res = 0;

					while (chaine.length != 0) 
					{
						retour = Remplissage(chaine);
							if (retour == false ) {
							    	comp = 10 - chaine[0];
									resultat[k] = chaine[0]; 
									chaine.splice(0, 1);
									k++;

									res = complement(comp, chaine);

									if(res){
										resultat[k] = chaine[res];
										chaine.splice(res, 1);
										k++;
									}														
							}
							else 
							{
								while(retour >= 0){
									resultat[k] = chaine[0];
									chaine.splice(0, 1);
									retour--;	
									k++;
								    }
							    }

					resultat[k]='/'; k++;
				    }


			var reg = new RegExp( ",","g");
		   	console.log(resultat.toString().replace(reg,""));

				}();
});

						

